//
//  UIColor+A_Extension.h
//  A_IOSHelper
//
//  Created by Animax on 3/19/15.
//  Copyright (c) 2015 AnimaxDeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (A_Extension)

+ (UIColor*) A_ColorMakeFormString:(NSString*) str;

@end
